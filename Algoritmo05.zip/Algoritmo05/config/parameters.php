<?php
define("base_url","http://localhost/Algoritmo05/");
define("controller_default","defaultController");
define("action_default","index");