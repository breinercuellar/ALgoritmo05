<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <ul>
        <li><a href="<?= base_url ?>estudiantes/registrar">Obtener promedio</a></li>
        <li><a href="<?= base_url ?>respuestas/registrar">Resultado de Pruebas</a></li>
        <li><a href="<?= base_url ?>partidos/registrar">Resultado de partidos</a></li>
    </ul>
    <h1>Aplicacion para tener promedios, mostrar resultados de pruebas y resultados de partidos</h1>