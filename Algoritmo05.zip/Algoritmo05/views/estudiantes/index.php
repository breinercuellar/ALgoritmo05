<h1>Bienvenido estudiante!</h1>
<p>Aqui podra encontrar ingresar sus notas y verificar su promedio.</p>

<a href="<?= base_url ?>estudiantes/registrar" >registrar</a>