<?php

echo "El equipo " . $partido->getEquipo() . " tuvo una puntuación de: " . $partido->darResultado();